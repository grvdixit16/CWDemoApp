import React from 'react';
import logo from '../assets/images/connectwiseLogo.png'; // with import

export class HeaderHolder extends React.Component {
    render(){
        return(

            <header className="header-area header-sticky background-header">
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        <nav className="main-nav">
                            <a href="#" className="logo">
                                <img  src={logo} style={{width: '35%'}} align="Connectwise Demo App"></img>
                            </a>
                            <ul className="nav">
                                <li className="scroll-to-section"><a href="#top" className="">Home</a></li>
                                <li className="scroll-to-section"><a href="#about" className="">About</a></li>
                               <li className="scroll-to-section"><a href="#reservation" className="">Contact Us</a></li> 
                            </ul>        
                        </nav>
                    </div>
                </div>
            </div>
        </header>

        );
    }
}

export default HeaderHolder;
