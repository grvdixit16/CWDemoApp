// import { createStore, applyMiddleware } from 'redux';
// import thunkMiddleware from 'redux-thunk';
// import { createLogger } from 'redux-logger';
// import rootReducer from '../reducers';
 
// const loggerMiddleware = createLogger();
 
// export const store = createStore(
//     rootReducer,
//     applyMiddleware(
//         thunkMiddleware,
//         loggerMiddleware
//     )
// );



 import React from 'react';
 import { applyMiddleware, createStore } from 'redux';
 import employeeReducer from '../reducers/employee';
 import thunk from "redux-thunk";

 export const store = createStore(
     employeeReducer, applyMiddleware(thunk));